CREATE DATABASE IF NOT EXISTS librarydata;
USE librarydata;

CREATE TABLE IF NOT EXISTS books_dataset (
    serial_no INT PRIMARY KEY,
    book_name VARCHAR(255),
    author_name VARCHAR(255),
    genre VARCHAR(100)
);
USE librarydata;
CREATE TABLE issued_books (
    serial_no INT NOT NULL,
    user_id INT NOT NULL,
    issue_date DATE NOT NULL,
    PRIMARY KEY (serial_no, user_id),
    FOREIGN KEY (serial_no) REFERENCES books_dataset(serial_no)
);

USE librarydata;
SELECT * FROM books_dataset 
LIMIT 10;
