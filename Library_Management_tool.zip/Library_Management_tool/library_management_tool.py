import gradio as gr
import mysql.connector
from mysql.connector import pooling
from datetime import datetime

# Database connection details
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "PassKush@99",  # Consider using environment variables for credentials
    "database": "librarydata",
    "pool_name": "mypool",
    "pool_size": 5,
    "connect_timeout": 10
}

# Initialize connection pool
def init_connection_pool():
    try:
        cnxpool = mysql.connector.pooling.MySQLConnectionPool(**DB_CONFIG)
        return cnxpool
    except mysql.connector.Error as err:
        print(f"Error initializing connection pool: {err}")
        return None

# Get connection from pool
def get_connection():
    pool = init_connection_pool()
    if not pool:
        print("Connection pool is not initialized.")
        return None
    try:
        conn = pool.get_connection()
        if conn.is_connected():
            return conn
        else:
            print("Failed to connect to the database.")
            return None
    except mysql.connector.Error as err:
        print(f"Error getting connection: {err}")
        return None

# UPDATED: Function to add a new book with automatic serial_no handling
def add_book(book_name, author_name, genre):
    if not book_name or not author_name or not genre:
        return "ℹ️ Please provide all the book details (Name, Author, Genre)."
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor()
            
            # First, find the maximum serial_no value
            cursor.execute("SELECT MAX(serial_no) FROM books_dataset")
            result = cursor.fetchone()
            
            # Generate a new serial_no (max + 1 or 1 if table is empty)
            next_serial = 1
            if result[0] is not None:
                next_serial = result[0] + 1
            
            # Insert with the new serial_no
            query = "INSERT INTO books_dataset (serial_no, book_name, author_name, genre) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (next_serial, book_name, author_name, genre))
            conn.commit()
            return f"✅ Book '{book_name}' by {author_name} added successfully with serial #: {next_serial}!"
        except mysql.connector.Error as err:
            conn.rollback()
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to browse books
def browse_books():
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            query = '''
                SELECT b.serial_no, b.book_name, b.author_name, b.genre,
                       CASE WHEN i.serial_no IS NULL THEN 'Available' ELSE 'Issued' END AS status
                FROM books_dataset b
                LEFT JOIN issued_books i ON b.serial_no = i.serial_no;
            '''
            cursor.execute(query)
            books = cursor.fetchall()
            if books:
                # Format output for Gradio
                result = ""
                for book in books:
                    result += f"📕 Book #{book['serial_no']}: {book['book_name']}\n"
                    result += f"✍️ Author: {book['author_name']}\n"
                    result += f"🏷️ Genre: {book['genre']}\n"
                    status_icon = "✅" if book['status'] == 'Available' else "❌"
                    result += f"📚 Status: {status_icon} {book['status']}\n"
                    result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                return result
            else:
                return "📚 No books found in the library database."
        except mysql.connector.Error as err:
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to search for books
def search_books(search_term):
    if not search_term:
        return "ℹ️ Please enter a search term."
    
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            query = '''
                SELECT b.serial_no, b.book_name, b.author_name, b.genre,
                       CASE WHEN i.serial_no IS NULL THEN 'Available' ELSE 'Issued' END AS status
                FROM books_dataset b
                LEFT JOIN issued_books i ON b.serial_no = i.serial_no
                WHERE b.book_name LIKE %s OR b.author_name LIKE %s OR b.genre LIKE %s;
            '''
            search_param = f'%{search_term}%'
            cursor.execute(query, (search_param, search_param, search_param))
            books = cursor.fetchall()
            if books:
                # Format output for Gradio
                result = f"🔍 Search results for '{search_term}':\n\n"
                for book in books:
                    result += f"📕 Book #{book['serial_no']}: {book['book_name']}\n"
                    result += f"✍️ Author: {book['author_name']}\n"
                    result += f"🏷️ Genre: {book['genre']}\n"
                    status_icon = "✅" if book['status'] == 'Available' else "❌"
                    result += f"📚 Status: {status_icon} {book['status']}\n"
                    result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                return result
            else:
                return f"🔍 No books found matching '{search_term}'."
        except mysql.connector.Error as err:
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to search for book status
def search_book_status(search_term):
    if not search_term:
        return "ℹ️ Please enter a book name to search."
    
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor(dictionary=True)
            query = '''
                SELECT b.serial_no, b.book_name, b.author_name, b.genre,
                       CASE WHEN i.serial_no IS NULL THEN 'Available' 
                            ELSE CONCAT('Issued to user ID: ', i.user_id, ' on ', i.issue_date) 
                       END AS status
                FROM books_dataset b
                LEFT JOIN issued_books i ON b.serial_no = i.serial_no
                WHERE b.book_name LIKE %s;
            '''
            cursor.execute(query, (f'%{search_term}%',))
            books = cursor.fetchall()
            if books:
                # Format output for Gradio
                result = f"🔍 Status search results for '{search_term}':\n\n"
                for book in books:
                    result += f"📕 Book #{book['serial_no']}: {book['book_name']}\n"
                    result += f"✍️ Author: {book['author_name']}\n"
                    result += f"🏷️ Genre: {book['genre']}\n"
                    status_icon = "✅" if book['status'] == 'Available' else "⏳"
                    result += f"📚 Status: {status_icon} {book['status']}\n"
                    result += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                return result
            else:
                return f"🔍 No books found matching '{search_term}'."
        except mysql.connector.Error as err:
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to issue a book
def issue_book(book_name, user_id):
    if not book_name or not user_id:
        return "ℹ️ Please enter both book name and user ID."
    
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor()
            # Check if book exists
            cursor.execute("SELECT serial_no FROM books_dataset WHERE book_name = %s", (book_name,))
            result = cursor.fetchone()

            if not result:
                return "📚 Book not found in the database."

            serial_no = result[0]

            # Check if book is already issued
            cursor.execute("SELECT * FROM issued_books WHERE serial_no = %s", (serial_no,))
            if cursor.fetchone():
                return "⚠️ Book is already issued to someone else."

            # Issue the book
            issue_date = datetime.now().strftime('%Y-%m-%d')
            cursor.execute("INSERT INTO issued_books (serial_no, user_id, issue_date) VALUES (%s, %s, %s)",
                           (serial_no, user_id, issue_date))
            conn.commit()
            return f"✅ Book '{book_name}' issued successfully to user ID: {user_id}!"
        except mysql.connector.Error as err:
            conn.rollback()  # Roll back on error
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to return a book
def return_book(book_name):
    if not book_name:
        return "ℹ️ Please enter a book name."
    
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor()
            # Check if book exists and get its serial number
            cursor.execute("SELECT serial_no FROM books_dataset WHERE book_name = %s", (book_name,))
            result = cursor.fetchone()

            if not result:
                return f"📚 Book '{book_name}' not found in the database."

            serial_no = result[0]

            # Check if book is issued
            cursor.execute("SELECT * FROM issued_books WHERE serial_no = %s", (serial_no,))
            if not cursor.fetchone():
                return f"ℹ️ Book '{book_name}' is not currently issued."

            # Return the book
            cursor.execute("DELETE FROM issued_books WHERE serial_no = %s", (serial_no,))
            conn.commit()
            return f"✅ Book '{book_name}' returned successfully!"
        except mysql.connector.Error as err:
            conn.rollback()  # Roll back on error
            return f"⚠️ Database error: {err}"
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    else:
        return "⚠️ Could not connect to database."

# Function to get available books for dropdown
def get_available_books():
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT b.book_name 
                FROM books_dataset b 
                LEFT JOIN issued_books i ON b.serial_no = i.serial_no 
                WHERE i.serial_no IS NULL
            ''')
            books = [row[0] for row in cursor.fetchall()]
            return books if books else ["No available books"]
        except mysql.connector.Error as err:
            print(f"Error getting available books: {err}")
            return ["Error loading books"]
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    return ["Database connection error"]

# Function to get issued books for dropdown
def get_issued_books():
    conn = get_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT b.book_name 
                FROM books_dataset b 
                INNER JOIN issued_books i ON b.serial_no = i.serial_no
            ''')
            books = [row[0] for row in cursor.fetchall()]
            return books if books else ["No issued books"]
        except mysql.connector.Error as err:
            print(f"Error getting issued books: {err}")
            return ["Error loading books"]
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    return ["Database connection error"]

# Custom CSS for styling
custom_css = """
.gradio-container {
    font-family: 'Poppins', sans-serif !important;
    max-width: 1000px !important;
    margin: auto;
}

h1 {
    color: #1a5fb4 !important;
    text-align: center;
    font-size: 2.5rem !important;
    margin-bottom: 1.5rem !important;
    border-bottom: 2px solid #1a5fb4;
    padding-bottom: 0.5rem;
}

.tab-nav {
    background-color: #f0f5ff !important;
    border-radius: 10px !important;
    padding: 0.5rem !important;
    margin-bottom: 1rem !important;
}

.tab-nav button {
    border-radius: 8px !important;
    margin: 0.25rem !important;
    font-weight: bold !important;
}

.tab-nav button.selected {
    background-color: #1a5fb4 !important;
    color: white !important;
}

button.primary {
    background-color: #1a5fb4 !important;
    color: white !important;
    border-radius: 8px !important;
    font-weight: bold !important;
    transition: all 0.3s ease !important;
}

button.primary:hover {
    background-color: #0d4599 !important;
    box-shadow: 0 4px 12px rgba(26, 95, 180, 0.3) !important;
}

.output-textbox {
    font-family: 'Roboto Mono', monospace !important;
    border-radius: 10px !important;
    border: 1px solid #ddd !important;
    background-color: #f8f9fa !important;
}

.input-container {
    margin-bottom: 1rem !important;
}

.footer {
    text-align: center;
    margin-top: 2rem;
    font-size: 0.9rem;
    color: #666;
}
"""

# Create Gradio interface
with gr.Blocks(title="Library Management System", css=custom_css) as app:
    gr.Markdown("# 📚 Library Management System")
    
    with gr.Tabs():
        with gr.Tab("📋 Browse Books"):
            browse_button = gr.Button("📚 Browse All Books", variant="primary")
            browse_output = gr.Textbox(label="Results", lines=20, elem_classes=["output-textbox"])
            browse_button.click(fn=browse_books, inputs=[], outputs=browse_output)
    
        with gr.Tab("🔍 Search Books"):
            with gr.Row():
                search_books_input = gr.Textbox(
                    label="Enter Book Name, Author, or Genre", 
                    placeholder="Search for books...",
                    elem_classes=["input-container"]
                )
                search_books_button = gr.Button("🔍 Search", variant="primary")
            
            search_books_output = gr.Textbox(
                label="Results", 
                lines=20, 
                elem_classes=["output-textbox"]
            )
            search_books_button.click(fn=search_books, inputs=search_books_input, outputs=search_books_output)
    
        with gr.Tab("📌 Book Status"):
            with gr.Row():
                search_input = gr.Textbox(
                    label="Enter Book Name", 
                    placeholder="Check book status...",
                    elem_classes=["input-container"]
                )
                search_button = gr.Button("📋 Check Status", variant="primary")
            
            status_output = gr.Textbox(
                label="Results", 
                lines=20, 
                elem_classes=["output-textbox"]
            )
            search_button.click(fn=search_book_status, inputs=search_input, outputs=status_output)
        
        with gr.Tab("➕ Add Book"):
            book_name_input = gr.Textbox(
                label="Book Name", 
                placeholder="Enter book name...",
                elem_classes=["input-container"]
            )
            author_name_input = gr.Textbox(
                label="Author Name", 
                placeholder="Enter author name...",
                elem_classes=["input-container"]
            )
            genre_input = gr.Textbox(
                label="Genre", 
                placeholder="Enter genre...",
                elem_classes=["input-container"]
            )
            add_button = gr.Button("➕ Add Book", variant="primary")
            add_output = gr.Textbox(
                label="Result",
                elem_classes=["output-textbox"]
            )
            add_button.click(fn=add_book, inputs=[book_name_input, author_name_input, genre_input], outputs=add_output)
            
            gr.Markdown("ℹ️ *Fill in all fields to add a new book to the library*")
    
        with gr.Tab("📤 Issue Book"):
            # Create a wrapper function for refreshing available books
            def update_available_books():
                books = get_available_books()
                return gr.Dropdown(choices=books, value=books[0] if books else None)
                
            with gr.Row():
                issue_book_input = gr.Dropdown(
                    label="Select Book", 
                    choices=get_available_books(),
                    elem_classes=["input-container"]
                )
                issue_user_id = gr.Number(
                    label="User ID", 
                    minimum=1, 
                    maximum=100, 
                    step=1, 
                    value=1,
                    elem_classes=["input-container"]
                )
            
            with gr.Row():
                refresh_issue_button = gr.Button("🔄 Refresh Available Books", variant="secondary")
                issue_button = gr.Button("📤 Issue Book", variant="primary")
            
            issue_output = gr.Textbox(
                label="Result", 
                elem_classes=["output-textbox"]
            )
            
            refresh_issue_button.click(
                fn=update_available_books,
                inputs=[],
                outputs=issue_book_input
            )
            
            issue_button.click(
                fn=issue_book,
                inputs=[issue_book_input, issue_user_id],
                outputs=issue_output
            )
            
            issue_button.click(
                fn=update_available_books,
                inputs=[],
                outputs=issue_book_input,
                queue=False
            )
            
            gr.Markdown("ℹ️ *Select a book from the dropdown and enter a user ID to issue a book*")
    
        with gr.Tab("📥 Return Book"):
            # Create a wrapper function for refreshing issued books
            def update_issued_books():
                books = get_issued_books()
                return gr.Dropdown(choices=books, value=books[0] if books else None)
                
            with gr.Row():
                return_book_input = gr.Dropdown(
                    label="Select Book", 
                    choices=get_issued_books(),
                    elem_classes=["input-container"]
                )
            
            with gr.Row():
                refresh_return_button = gr.Button("🔄 Refresh Issued Books", variant="secondary")
                return_button = gr.Button("📥 Return Book", variant="primary")
            
            return_output = gr.Textbox(
                label="Result",
                elem_classes=["output-textbox"]
            )
            
            refresh_return_button.click(
                fn=update_issued_books,
                inputs=[],
                outputs=return_book_input
            )
            
            return_button.click(
                fn=return_book,
                inputs=return_book_input,
                outputs=return_output
            )
            
            return_button.click(
                fn=update_issued_books,
                inputs=[],
                outputs=return_book_input,
                queue=False
            )
            
            gr.Markdown("ℹ️ *Select a book from the dropdown to return it to the library*")
    
    gr.Markdown("""
    <div class="footer">
        <p>Library Management System | © 2025 | Developed with Gradio</p>
    </div>
    """)

# Launch the app
if __name__ == "__main__":
    app.launch()